from socket_control import socket_control

class wiz_scpi(socket_control):
    def __init__(self):
        super().__init__()


